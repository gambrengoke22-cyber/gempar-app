export async function onRequestGet(context) {
  const { env, request } = context;
  const url = new URL(request.url);

  const page = parseInt(url.searchParams.get("page") || "1");
  const limit = parseInt(url.searchParams.get("limit") || "20");
  const rw = url.searchParams.get("rw") || "";
  const search = url.searchParams.get("search") || "";
  const nikValid = url.searchParams.get("nik_valid");
  const status = url.searchParams.get("status") || "";

  try {
    let whereClauses = ["1=1"];
    let params = [];

    if (rw) {
      whereClauses.push("rw = ?");
      params.push(rw);
    }
    if (status) {
      whereClauses.push("status = ?");
      params.push(status);
    }
    if (nikValid !== null && nikValid !== "") {
      whereClauses.push("nik_valid = ?");
      params.push(parseInt(nikValid));
    }
    if (search) {
      whereClauses.push("(nama LIKE ? OR nik LIKE ? OR gem_id LIKE ?)");
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    const whereSql = whereClauses.join(" AND ");

    // Count total
    const countStmt = env.DB.prepare(`SELECT COUNT(*) as total FROM members WHERE ${whereSql}`);
    const countResult = await countStmt.bind(...params).first();
    const total = countResult?.total || 0;

    // Fetch data
    const offset = (page - 1) * limit;
    const dataStmt = env.DB.prepare(`
      SELECT * FROM members 
      WHERE ${whereSql} 
      ORDER BY rw ASC, nama ASC 
      LIMIT ? OFFSET ?
    `);
    const dataResult = await dataStmt.bind(...params, limit, offset).all();

    return jsonResponse({
      success: true,
      data: dataResult.results || [],
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message }, 500);
  }
}

export async function onRequestPost(context) {
  const { env, request } = context;

  try {
    const body = await request.json();
    const { nama, nik, rw, rt, status, keterangan } = body;

    if (!nama || !rw) {
      return jsonResponse({ success: false, error: "Nama dan RW wajib diisi" }, 400);
    }

    // Validasi NIK
    let nikValid = 1;
    let cleanNik = (nik || "").replace(/\D/g, "");
    if (cleanNik && cleanNik.length !== 16) {
      nikValid = 0;
    }

    const gemId = await generateUniqueGemId(env.DB, nama, cleanNik);

    const result = await env.DB.prepare(`
      INSERT INTO members (nama, nik, rw, rt, gem_id, status, nik_valid, keterangan)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      RETURNING *
    `).bind(nama, cleanNik || null, rw, rt || null, gemId, status || "Aktif", nikValid, keterangan || "").first();

    return jsonResponse({ success: true, data: result }, 201);
  } catch (err) {
    if (err.message && err.message.includes("UNIQUE constraint failed")) {
      return jsonResponse({ success: false, error: "GEM-ID atau NIK sudah terdaftar" }, 409);
    }
    return jsonResponse({ success: false, error: err.message }, 500);
  }
}

async function generateUniqueGemId(db, nama, nik) {
  const namaDepan = nama.trim().split(/\s+/)[0].toUpperCase();
  const nikLast4 = nik.slice(-4).padStart(4, "0") || "0000";
  let gemId = `${namaDepan}-${nikLast4}`;

  const existing = await db.prepare("SELECT gem_id FROM members WHERE gem_id = ?").bind(gemId).first();
  if (!existing) return gemId;

  let suffix = 1;
  while (true) {
    const newId = `${namaDepan}-${String.fromCharCode(64 + suffix)}-${nikLast4}`;
    const check = await db.prepare("SELECT gem_id FROM members WHERE gem_id = ?").bind(newId).first();
    if (!check) return newId;
    suffix++;
    if (suffix > 26) {
      return `${namaDepan}-${Date.now()}-${nikLast4}`;
    }
  }
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
