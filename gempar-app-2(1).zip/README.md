# GEMPAR App - Cloudflare Pages + D1

## Gerakan Pilah Sampah Warakas
Aplikasi manajemen anggota Jumantik dengan 14 RW.

## Quick Deploy (HP → Cloudflare Pages)

### 1. Persiapan File
- ZIP semua file di folder ini
- Atau push ke GitHub

### 2. Buat D1 Database
1. Buka [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Workers & Pages → D1 → Create Database
3. Beri nama: `gempar-db`
4. Copy **Database ID**

### 3. Deploy Pages
1. Workers & Pages → Create a Project → Pages
2. Upload ZIP atau Connect GitHub
3. Project name: `gempar-app`
4. Build settings: biarkan default (kosongkan build command)
5. Deploy

### 4. Bind D1 ke Pages
1. Buka project GEMPAR → Settings → Functions
2. D1 Database Bindings → Add Binding
3. Variable name: `DB`
4. Pilih database: `gempar-db`
5. Save

### 5. Inisialisasi Database
1. Buka URL project kamu
2. Klik tombol **"⚙️ Init DB"** di pojok kanan atas
3. Tunggu sampai muncul notifikasi sukses
4. Selesai! Aplikasi siap digunakan

## API Endpoints

| Method | Endpoint | Keterangan |
|--------|----------|------------|
| POST | `/api/init` | Setup database + sample data |
| GET | `/api/members` | List anggota (query: page, limit, rw, search, status, nik_valid) |
| POST | `/api/members` | Tambah anggota baru |
| GET | `/api/member/:id` | Detail anggota |
| PUT | `/api/member/:id` | Update anggota |
| DELETE | `/api/member/:id` | Hapus anggota |
| GET | `/api/stats` | Statistik dashboard |
| POST | `/api/import` | Import bulk CSV/JSON |

## Format GEM-ID
```
NamaDepan-4digitNIK
Contoh: FARAH-0014, SITI-J-0018
```
Auto-generate saat tambah anggota. Duplikat auto-suffix A-Z.

## Import CSV Format
```csv
nama,nik,rw,rt,status,keterangan
Farah Aulia,3175091405870014,01,01,Aktif,
Siti Jumantik,3175091405870018,02,03,Aktif,
```

## Local Development (Opsional)
```bash
# Install Wrangler
npm install -g wrangler

# Login
wrangler login

# Jalankan local server
wrangler pages dev .

# Jalankan D1 local
wrangler d1 execute gempar-db --local --file=./schema.sql
```

## Catatan Penting
- **Jangan lupa ganti `database_id` di `wrangler.toml`** dengan ID D1 kamu
- Tombol **Init DB** hanya perlu dijalankan **sekali** saat setup awal
- NIK auto-validasi: harus 16 digit angka
- 2 NIK invalid (ID 160 & 165) sudah ditandai di sample data
